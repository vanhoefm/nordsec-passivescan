import android

droid = android.Android()
droid.cameraCapturePicture('/sdcard/foo.jpg')
